var playing = false;
var score;
var action;
var timeremaining;
var correctanswer;
document.getElementById("startreset").onclick=function()
{
    if(playing == true)
    {
        location.reload(); //reload page
    }
    else
    {
        score = 0;
        playing = true;
        document.getElementById("scorevalue").innerHTML = score;
        document.getElementById("timeremaining").style.display = "block"
        document.getElementById("startreset").innerHTML = "Reset Game";
        timeremaining = 60;
        document.getElementById("time").innerHTML = timeremaining;
        hide("gameover");
        startcountdown();
        generateqa();
    }
}
for(j=1;j<5;j++)
{
document.getElementById("box"+j).onclick = function()
{
    if (playing == true)
    {
        if(this.innerHTML == correctanswer)
        {
            score++;
            document.getElementById("scorevalue").innerHTML = score;
            hide("wrong");
            show("correct");
            setTimeout(function()
            {
                hide("correct")
            },1000);
            generateqa();
        }
        else
        {
            hide("correct");
            show("wrong");
            setTimeout(function()
            {
                hide("wrong")
            },1000);
        }
    }
}
}
    //playing  
        //reload page
    //not playing
        //set score to 0
        //show countdown box
        //reduce time by 1s
            //timeleft?
                //yes-> Continue
                //no->gameover
            //change button to reset
            //generate new Question

//if click on answer box
    //if we are playing?
        //yes
            //increase score
            //show correct box for 1s
            //generate new Question
        //no
            //show try again box for 1s
function startcountdown()
{
 action = setInterval(function()
 {
    timeremaining -=1;
    document.getElementById("time").innerHTML = timeremaining;
        if(timeremaining == 0)
            stopcountdown();
 },1000)
}

function stopcountdown()
{
    clearInterval(action);
    show("gameover");
    document.getElementById("gameover").innerHTML = "<p>Game Over!</p><p>Your Score Is " +score+ ".</P>";
    hide("timeremaining");
    hide("correct");
    hide("wrong");
    playing = false;
    document.getElementById("startreset").innerHTML ="Start";
}

function hide(id)
{
    document.getElementById(id).style.display = "none";
}

function show(id)
{
    document.getElementById(id).style.display = "block";
}

function generateqa()
{
    var x = 1 + Math.round(9*Math.random());
    var y = 1 + Math.round(9*Math.random());
    correctanswer = x*y;
    document.getElementById("question").innerHTML = x +"*"+ y;
    var correctposition = 1 + Math.round(3*Math.random());
    document.getElementById("box"+correctposition).innerHTML = correctanswer;
    var answers = [correctanswer];
    for(var i=1; i<5; i++)
    {
        if(i != correctposition)
        {
            var wronganswer 
            do
            {
                wronganswer = (1 + Math.round(9*Math.random())) * (1 + Math.round(9*Math.random()));
            }
            while(answers.indexOf(wronganswer)>-1)
            document.getElementById("box"+i).innerHTML = wronganswer;
            answers.push(wronganswer);
        }
    }
}


